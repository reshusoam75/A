'use strict';

const API_BASE = '/api';
let allMovies = [];
let heroMovie = null;

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  loadMovies();
});

// ===== FETCH MOVIES =====
async function loadMovies() {
  try {
    const res = await fetch(`${API_BASE}/movies`);
    if (!res.ok) throw new Error('Failed to fetch movies');
    const data = await res.json();
    allMovies = data.movies || [];
    renderMovies(allMovies);
    renderHero(allMovies);
  } catch (err) {
    console.error('loadMovies error:', err);
    document.getElementById('movieGrid').innerHTML = `
      <div class="empty-state">
        <h3>Could not load movies</h3>
        <p>Make sure the server is running and MongoDB is connected.</p>
      </div>`;
  }
}

// ===== RENDER HERO =====
function renderHero(movies) {
  const hero = document.getElementById('heroSection');
  if (!movies || movies.length === 0) {
    document.getElementById('heroTitle').textContent = 'No Movies Yet';
    document.getElementById('heroDesc').textContent = 'Upload videos to your Telegram channel to get started.';
    return;
  }

  // Pick movie with highest rating or first one with a poster
  heroMovie = movies.find(m => m.poster) || movies[0];

  document.getElementById('heroTitle').textContent = heroMovie.title || 'Untitled';
  document.getElementById('heroDesc').textContent = heroMovie.description || '';
  document.getElementById('heroRating').textContent = heroMovie.rating ? `⭐ ${heroMovie.rating}` : '';
  document.getElementById('heroYear').textContent = heroMovie.year || '';

  if (heroMovie.poster) {
    let bg = hero.querySelector('.hero-bg-img');
    if (!bg) {
      bg = document.createElement('div');
      bg.className = 'hero-bg-img';
      hero.insertBefore(bg, hero.firstChild);
    }
    bg.style.backgroundImage = `url('${heroMovie.poster}')`;
  }
}

// ===== PLAY HERO =====
function playHero() {
  if (heroMovie) openModal(heroMovie);
}

// ===== RENDER MOVIES GRID =====
function renderMovies(movies) {
  const grid = document.getElementById('movieGrid');
  if (!movies || movies.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <h3>No Movies Found</h3>
        <p>Upload videos with a caption to your Telegram channel to add movies.</p>
      </div>`;
    return;
  }

  grid.innerHTML = movies.map(movie => `
    <div class="movie-card" onclick="openModal(${JSON.stringify(movie).replace(/"/g, '&quot;')})">
      ${movie.poster
        ? `<img class="movie-poster" src="${movie.poster}" alt="${escapeHtml(movie.title)}" loading="lazy" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'" />`
        : ''}
      <div class="movie-poster-placeholder" style="${movie.poster ? 'display:none' : ''}">
        <span class="poster-icon">🎬</span>
        <span>${escapeHtml(movie.title)}</span>
      </div>
      <div class="movie-card-overlay">
        <button class="overlay-play-btn">&#9654;</button>
      </div>
      <div class="movie-card-info">
        <div class="movie-card-title">${escapeHtml(movie.title)}</div>
        <div class="movie-card-meta">
          <span class="movie-card-rating">${movie.rating ? '⭐ ' + movie.rating : ''}</span>
          <span>${movie.year || ''}</span>
        </div>
      </div>
    </div>
  `).join('');
}

// ===== OPEN MODAL =====
function openModal(movie) {
  const overlay = document.getElementById('modalOverlay');
  const video = document.getElementById('videoPlayer');

  document.getElementById('modalTitle').textContent = movie.title || 'Untitled';
  document.getElementById('modalRating').textContent = movie.rating ? `⭐ ${movie.rating}` : '';
  document.getElementById('modalYear').textContent = movie.year || '';
  document.getElementById('modalGenre').textContent = Array.isArray(movie.genre) ? movie.genre.join(', ') : (movie.genre || '');
  document.getElementById('modalDesc').textContent = movie.description || 'No description available.';

  // Set video source to stream endpoint
  const streamUrl = `${API_BASE}/stream/${encodeURIComponent(movie.file_id)}`;

  // Check if stream is accessible before setting src
  video.src = '';
  video.removeAttribute('src');
  const errorBox = document.getElementById('streamError');
  if (errorBox) errorBox.remove();

  // Try HEAD request to check stream availability
  fetch(streamUrl, { method: 'HEAD' }).then(r => {
    if (r.status === 413 || r.status === 404) {
      return r.json ? r.json() : { error: 'FILE_TOO_BIG' };
    }
    // Stream available — set video src
    video.src = streamUrl;
    video.load();
    return null;
  }).then(errData => {
    if (!errData) return;
    const isBig = errData?.error === 'FILE_TOO_BIG';
    const msg = document.createElement('div');
    msg.id = 'streamError';
    msg.style.cssText = 'background:#1a0a0a;border:1px solid #e50914;border-radius:8px;padding:20px 24px;color:#f0f0f0;font-size:0.9rem;line-height:1.7;margin:0';
    msg.innerHTML = isBig
      ? `<strong style="color:#e50914">⚠ File too large to stream via Bot API</strong><br>
         Telegram's Bot API only supports files up to 20MB. To stream full movies:<br><br>
         <strong>Option A — Local Bot API Server (recommended):</strong><br>
         1. Run <code style="background:#111;padding:2px 6px;border-radius:4px">telegram-bot-api</code> locally or on your server<br>
         2. Set env: <code style="background:#111;padding:2px 6px;border-radius:4px">TELEGRAM_LOCAL_API_URL=http://localhost:8081</code><br>
         3. Restart the server — streaming will work for any file size<br><br>
         <a href="https://github.com/tdlib/telegram-bot-api" target="_blank" style="color:#e50914">→ telegram-bot-api GitHub</a>`
      : `<strong style="color:#e50914">⚠ Stream unavailable</strong><br>${errData?.error ?? 'Could not reach Telegram file.'}`;
    const player = document.querySelector('.modal-player');
    if (player) player.appendChild(msg);
  }).catch(() => {
    // Network error — still try to play
    video.src = streamUrl;
    video.load();
  });

  overlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

// ===== CLOSE MODAL =====
function closeModal() {
  const overlay = document.getElementById('modalOverlay');
  const video = document.getElementById('videoPlayer');
  overlay.classList.remove('active');
  video.pause();
  video.src = '';
  document.body.style.overflow = '';
}

// ===== SEARCH =====
async function handleSearch(event) {
  event.preventDefault();
  const q = document.getElementById('searchInput').value.trim();
  const sectionTitle = document.getElementById('sectionTitle');

  try {
    if (!q) {
      sectionTitle.textContent = 'All Movies';
      renderMovies(allMovies);
      return;
    }

    sectionTitle.textContent = `Results for "${q}"`;
    document.getElementById('movieGrid').innerHTML = '<div class="loading-spinner">Searching...</div>';

    const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(q)}`);
    if (!res.ok) throw new Error('Search failed');
    const data = await res.json();
    renderMovies(data.movies || []);
  } catch (err) {
    console.error('search error:', err);
    document.getElementById('movieGrid').innerHTML = `
      <div class="empty-state"><h3>Search failed</h3><p>Please try again.</p></div>`;
  }
}

// ===== KEYBOARD =====
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

// ===== UTILS =====
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
