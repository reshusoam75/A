import type { Request, Response } from "express";
import Movie from "../models/Movie.js";
import { proxyTelegramStream, getTelegramFileUrl } from "../services/telegram.js";
import { streamViaGramJS, getGramJSClient } from "../services/gramjs.js";

export async function getMovies(req: Request, res: Response): Promise<void> {
  try {
    const movies = await Movie.find().sort({ created_at: -1 }).lean();
    res.json({ movies });
  } catch (err) {
    req.log.error({ err }, "getMovies error");
    res.status(500).json({ error: "Failed to fetch movies" });
  }
}

export async function getMovieById(req: Request, res: Response): Promise<void> {
  try {
    const movie = await Movie.findById(req.params.id).lean();
    if (!movie) {
      res.status(404).json({ error: "Movie not found" });
      return;
    }
    res.json({ movie });
  } catch (err) {
    req.log.error({ err }, "getMovieById error");
    res.status(500).json({ error: "Failed to fetch movie" });
  }
}

export async function searchMovies(req: Request, res: Response): Promise<void> {
  try {
    const q = (req.query.q as string) ?? "";
    if (!q.trim()) {
      const movies = await Movie.find().sort({ created_at: -1 }).lean();
      res.json({ movies });
      return;
    }
    const movies = await Movie.find({
      $text: { $search: q },
    })
      .sort({ score: { $meta: "textScore" } })
      .lean();
    res.json({ movies });
  } catch (err) {
    req.log.error({ err }, "searchMovies error");
    res.status(500).json({ error: "Search failed" });
  }
}

export async function streamMovie(req: Request, res: Response): Promise<void> {
  const { file_id } = req.params;
  if (!file_id) {
    res.status(400).json({ error: "file_id is required" });
    return;
  }

  // Look up movie to get chat_id and message_id for GramJS streaming
  const movie = await Movie.findOne({ file_id }).lean();

  // HEAD request: check availability without streaming
  if (req.method === "HEAD") {
    // If we have MTProto info available, report as streamable
    if (movie?.chat_id && movie?.message_id && process.env.TELEGRAM_API_ID) {
      res.status(200).end();
      return;
    }
    const { url, error } = await getTelegramFileUrl(file_id);
    if (!url) {
      if (error === "FILE_TOO_BIG") {
        res.status(413).json({ error: "FILE_TOO_BIG" });
      } else {
        res.status(404).json({ error: error ?? "File not found" });
      }
      return;
    }
    res.status(200).end();
    return;
  }

  // Try GramJS (MTProto) first — no size limits, uses API_ID + API_HASH
  if (movie?.chat_id && movie?.message_id && process.env.TELEGRAM_API_ID) {
    req.log.info({ chat_id: movie.chat_id, message_id: movie.message_id }, "Streaming via GramJS MTProto");
    const success = await streamViaGramJS(movie.chat_id, movie.message_id, res as any);
    if (success) return;
    req.log.warn("GramJS stream failed, falling back to Bot API");
  }

  // Fallback: standard Bot API proxy (works for files ≤ 20MB)
  await proxyTelegramStream(file_id, req as any, res as any);
}
