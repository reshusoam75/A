import { Router, type Request, type Response } from "express";
import Movie from "../models/Movie.js";
import { fetchMovieMetadata } from "../services/tmdb.js";
import { getGramJSClient } from "../services/gramjs.js";
import { logger } from "../lib/logger.js";

const router = Router();

// POST /api/admin/refresh/:id — re-fetch TMDB data for a movie
router.post("/admin/refresh/:id", async (req: Request, res: Response) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) {
      res.status(404).json({ error: "Movie not found" });
      return;
    }

    // Use stored title to query TMDB
    const meta = await fetchMovieMetadata(movie.title);
    if (!meta) {
      res.status(404).json({ error: "TMDB returned no results for this title" });
      return;
    }

    movie.title = meta.title;
    movie.poster = meta.poster;
    movie.description = meta.description;
    movie.rating = meta.rating;
    movie.year = meta.year;
    movie.genre = meta.genre;
    await movie.save();

    logger.info({ title: movie.title }, "Movie refreshed from TMDB");
    res.json({ movie });
  } catch (err) {
    logger.error({ err }, "admin refresh error");
    res.status(500).json({ error: "Refresh failed" });
  }
});

// PATCH /api/admin/movie/:id — manually update title (triggers TMDB re-fetch)
router.patch("/admin/movie/:id", async (req: Request, res: Response) => {
  try {
    const { title } = req.body as { title?: string };
    if (!title) {
      res.status(400).json({ error: "title is required" });
      return;
    }

    const movie = await Movie.findById(req.params.id);
    if (!movie) {
      res.status(404).json({ error: "Movie not found" });
      return;
    }

    movie.title = title;
    const meta = await fetchMovieMetadata(title);
    if (meta) {
      movie.title = meta.title;
      movie.poster = meta.poster;
      movie.description = meta.description;
      movie.rating = meta.rating;
      movie.year = meta.year;
      movie.genre = meta.genre;
    }
    await movie.save();

    res.json({ movie });
  } catch (err) {
    logger.error({ err }, "admin patch error");
    res.status(500).json({ error: "Update failed" });
  }
});

// DELETE /api/admin/movie/:id
router.delete("/admin/movie/:id", async (req: Request, res: Response) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) {
      res.status(404).json({ error: "Movie not found" });
      return;
    }
    res.json({ success: true });
  } catch (err) {
    logger.error({ err }, "admin delete error");
    res.status(500).json({ error: "Delete failed" });
  }
});

// POST /api/admin/set-message/:id — manually set chat_id and message_id for a movie
router.post("/admin/set-message/:id", async (req: Request, res: Response) => {
  try {
    const { chat_id, message_id } = req.body as { chat_id?: number; message_id?: number };
    if (!chat_id || !message_id) {
      res.status(400).json({ error: "chat_id and message_id are required" });
      return;
    }
    const movie = await Movie.findByIdAndUpdate(
      req.params.id,
      { chat_id, message_id },
      { new: true }
    );
    if (!movie) { res.status(404).json({ error: "Movie not found" }); return; }
    res.json({ success: true, movie });
  } catch (err) {
    logger.error({ err }, "set-message error");
    res.status(500).json({ error: "Update failed" });
  }
});

// GET /api/admin/status — show which movies are ready for MTProto streaming
router.get("/admin/status", async (_req: Request, res: Response) => {
  try {
    const all = await Movie.find().lean();
    const ready = all.filter((m) => m.message_id && m.chat_id);
    const needsReupload = all.filter((m) => !m.message_id || !m.chat_id);
    res.json({
      total: all.length,
      streamingReady: ready.length,
      needsReupload: needsReupload.map((m) => ({ id: m._id, title: m.title })),
      gramjsAvailable: !!(process.env.TELEGRAM_API_ID && process.env.TELEGRAM_API_HASH),
    });
  } catch (err) {
    res.status(500).json({ error: "Status check failed" });
  }
});

export default router;
