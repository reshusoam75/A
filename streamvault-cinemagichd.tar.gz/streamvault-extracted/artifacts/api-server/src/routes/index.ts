import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import moviesRouter from "./movies.js";
import adminRouter from "./admin.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(moviesRouter);
router.use(adminRouter);

export default router;
