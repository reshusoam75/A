import { Router } from "express";
import {
  getMovies,
  getMovieById,
  searchMovies,
  streamMovie,
} from "../controllers/movieController.js";

const router = Router();

router.get("/movies", getMovies);
router.get("/movie/:id", getMovieById);
router.get("/search", searchMovies);
router.get("/stream/:file_id", streamMovie);

export default router;
