import mongoose, { Schema, Document } from "mongoose";

export interface IMovie extends Document {
  title: string;
  file_id: string;
  poster: string;
  description: string;
  rating: number;
  year: number;
  genre: string[];
  created_at: Date;
  chat_id?: number;
  message_id?: number;
}

const MovieSchema: Schema = new Schema(
  {
    title: { type: String, required: true },
    file_id: { type: String, required: true, unique: true },
    poster: { type: String, default: "" },
    description: { type: String, default: "" },
    rating: { type: Number, default: 0 },
    year: { type: Number, default: 0 },
    genre: { type: [String], default: [] },
    created_at: { type: Date, default: Date.now },
    chat_id: { type: Number },
    message_id: { type: Number },
  },
  { collection: "movies" }
);

MovieSchema.index({ title: "text" });

export default mongoose.model<IMovie>("Movie", MovieSchema);
