import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import router from "./routes/index.js";
import { logger } from "./lib/logger.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// REST API routes
app.use("/api", router);

// Serve static frontend at /api/static/
// In prod (bundled esbuild): __dirname resolves to dist/
// In dev: __dirname resolves to src/, public is one level up at ../public
const prodPublicDir = path.resolve(__dirname, "public");
const devPublicDir = path.resolve(__dirname, "../public");
const staticDir = fs.existsSync(prodPublicDir) ? prodPublicDir : devPublicDir;
app.use("/api/static", express.static(staticDir));

// Root redirect to the frontend
app.get("/", (_req, res) => {
  res.redirect("/api/static/");
});

export default app;
