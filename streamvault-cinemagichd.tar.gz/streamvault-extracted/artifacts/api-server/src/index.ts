import app from "./app.js";
import { logger } from "./lib/logger.js";
import { connectDB } from "./services/db.js";
import { startBot } from "./bot/index.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Start server immediately so health checks pass
app.listen(port, () => {
  logger.info({ port }, "Server listening");
});

// Connect to MongoDB in background (non-blocking)
connectDB()
  .then(() => {
    startBot();
  })
  .catch((err) => {
    logger.error(
      { err, hint: "Check MONGODB_URI and Atlas Network Access (allow 0.0.0.0/0)" },
      "MongoDB connection failed — API will return errors until DB is available"
    );
  });
