import { Telegraf, Context } from "telegraf";
import Movie from "../models/Movie.js";
import { fetchMovieMetadata } from "../services/tmdb.js";
import { logger } from "../lib/logger.js";

/**
 * Strip file-naming noise and return a clean movie/show title.
 * Handles patterns like:
 *   "Bloodhounds S01 1080p NF WEB-DL DUAL DDP5 1 H 265-ExtraFlix Pw part002 mkv 🔊 Audio: #Hindi"
 *   "The.Dark.Knight.2008.1080p.BluRay.x264"
 *   "Inception (2010) [BluRay] [1080p]"
 */
function cleanMovieTitle(raw: string): string {
  let title = raw;

  // Strip emojis
  title = title.replace(/[\u{1F300}-\u{1FFFF}]/gu, "");
  title = title.replace(/[\u2600-\u27FF]/g, "");

  // Strip hashtags and everything after them
  title = title.replace(/#\S+/g, "");

  // Strip common quality / codec / source noise patterns
  const noisePatterns = [
    /\b(2160p|1080p|1080i|720p|720i|480p|4K|HDR|SDR|UHD)\b/gi,
    /\b(BluRay|BDRip|BRRip|WEB-DL|WEBRip|HDTV|DVDRip|DVDScr|CAM|TS|R5)\b/gi,
    /\b(x264|x265|H\.?264|H\.?265|HEVC|AVC|XviD|DivX)\b/gi,
    /\b(DDP5\.?1|DD5\.?1|DTS|AAC|AC3|MP3|FLAC|Atmos|TrueHD)\b/gi,
    /\b(DUAL|MULTI|Hindi|Korean|English|Tamil|Telugu|Malayalam|Dubbed)\b/gi,
    /\b(NF|AMZN|DSNP|HULU|HBO|APPLE|PCOK|STAN|SHO|PMTP|CRAV)\b/gi,
    /\b(part\d+|cd\d+|disc\d+|disk\d+)\b/gi,
    /\b(REPACK|PROPER|EXTENDED|THEATRICAL|DIRECTORS\.?CUT|UNRATED)\b/gi,
    /\b\d{3,4}MB\b/gi,
    /\[-[^\]]+\]/g,     // [-GroupName]
    /\[[^\]]+\]/g,       // [anything in brackets]
    /\([^)]*\d{4}[^)]*\)/g, // (2008) or (2008 BluRay)
    /\.\w{2,4}$/i,       // file extension at end (.mkv, .mp4, .avi)
    /Audio[:：].*/gi,     // "Audio: Hindi, Korean" and everything after
    /\bPw\b/gi,
    /[_\.]/g,            // dots and underscores → spaces
  ];

  for (const pattern of noisePatterns) {
    title = title.replace(pattern, " ");
  }

  // Collapse multiple spaces and trim
  title = title.replace(/\s+/g, " ").trim();

  // If title is empty fall back to raw (cleaned minimally)
  if (!title) {
    title = raw.replace(/[._]/g, " ").trim();
  }

  return title;
}

let botInstance: Telegraf | null = null;

export function startBot(): void {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const channelId = process.env.TELEGRAM_CHANNEL_ID;

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not set — bot disabled");
    return;
  }
  if (!channelId) {
    logger.warn("TELEGRAM_CHANNEL_ID not set — bot disabled");
    return;
  }

  const bot = new Telegraf(token);
  botInstance = bot;

  // Handle channel posts with video or document
  bot.on("channel_post", async (ctx: Context) => {
    try {
      const post = ctx.channelPost;
      if (!post) return;

      // Only handle posts from our configured channel
      const chatId = String(post.chat.id);
      if (chatId !== channelId) return;

      let fileId: string | null = null;
      let caption = "";

      if ("video" in post && post.video) {
        fileId = post.video.file_id;
        caption = post.caption ?? post.video.file_name ?? "";
      } else if ("document" in post && post.document) {
        const mimeType = post.document.mime_type ?? "";
        if (mimeType.startsWith("video/")) {
          fileId = post.document.file_id;
          caption = post.caption ?? post.document.file_name ?? "";
        }
      }

      if (!fileId || !caption) {
        logger.info("channel_post: no video/document with caption, skipping");
        return;
      }

      // Clean the title from caption — strip quality tags, codec info, release group noise
      const title = cleanMovieTitle(caption);

      logger.info({ rawCaption: caption, cleanedTitle: title, fileId }, "Processing new movie upload");

      // Check if file already exists
      const existing = await Movie.findOne({ file_id: fileId });
      if (existing) {
        logger.info({ fileId }, "Movie already in DB, skipping");
        return;
      }

      // Fetch TMDB metadata
      const meta = await fetchMovieMetadata(title);

      const movieData = {
        title: meta?.title ?? title,
        file_id: fileId,
        poster: meta?.poster ?? "",
        description: meta?.description ?? "",
        rating: meta?.rating ?? 0,
        year: meta?.year ?? 0,
        genre: meta?.genre ?? [],
        created_at: new Date(),
        chat_id: post.chat.id,
        message_id: post.message_id,
      };

      await Movie.create(movieData);
      logger.info({ title: movieData.title, hasPoster: !!movieData.poster, chat_id: movieData.chat_id, message_id: movieData.message_id }, "Movie saved to DB");
    } catch (err) {
      logger.error({ err }, "Bot channel_post handler error");
    }
  });

  bot.launch().then(() => {
    logger.info("Telegram bot started (long polling)");
  }).catch((err) => {
    logger.error({ err }, "Failed to start Telegram bot");
  });

  // Graceful stop
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}
