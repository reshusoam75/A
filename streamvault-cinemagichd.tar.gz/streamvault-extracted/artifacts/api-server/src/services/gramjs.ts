import { TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions/index.js";
import { logger } from "../lib/logger.js";
import type { ServerResponse } from "http";

let client: TelegramClient | null = null;
let connecting = false;

export async function getGramJSClient(): Promise<TelegramClient | null> {
  const apiId = process.env.TELEGRAM_API_ID;
  const apiHash = process.env.TELEGRAM_API_HASH;
  const botToken = process.env.TELEGRAM_BOT_TOKEN;

  if (!apiId || !apiHash || !botToken) {
    return null;
  }

  if (client?.connected) return client;
  if (connecting) {
    // Wait for existing connection attempt
    await new Promise((r) => setTimeout(r, 3000));
    if (client?.connected) return client;
    return null;
  }

  connecting = true;
  try {
    client = new TelegramClient(
      new StringSession(""),
      parseInt(apiId, 10),
      apiHash,
      { connectionRetries: 3, timeout: 30 }
    );
    await client.start({ botAuthToken: botToken });
    logger.info("GramJS client connected (MTProto)");
    return client;
  } catch (err) {
    logger.error({ err }, "GramJS client connection failed");
    client = null;
    return null;
  } finally {
    connecting = false;
  }
}

export async function streamViaGramJS(
  chatId: number,
  messageId: number,
  res: ServerResponse
): Promise<boolean> {
  try {
    const tgClient = await getGramJSClient();
    if (!tgClient) {
      logger.warn("GramJS client unavailable");
      return false;
    }

    const [msg] = await tgClient.getMessages(chatId, { ids: [messageId] });
    if (!msg || !msg.media) {
      logger.warn({ chatId, messageId }, "GramJS: message or media not found");
      return false;
    }

    res.writeHead(200, {
      "Content-Type": "video/mp4",
      "Transfer-Encoding": "chunked",
      "Accept-Ranges": "none",
      "Cache-Control": "no-cache",
      "Access-Control-Allow-Origin": "*",
    });

    // Stream in 512KB chunks
    for await (const chunk of tgClient.iterDownload({
      file: msg.media as any,
      requestSize: 512 * 1024,
    })) {
      const canContinue = res.write(Buffer.from(chunk));
      if (!canContinue) {
        await new Promise<void>((resolve) => (res as any).once("drain", resolve));
      }
    }

    res.end();
    return true;
  } catch (err) {
    logger.error({ err }, "GramJS streamViaGramJS error");
    return false;
  }
}
