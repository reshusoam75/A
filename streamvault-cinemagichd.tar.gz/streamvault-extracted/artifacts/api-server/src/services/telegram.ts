import { logger } from "../lib/logger.js";
import type { IncomingMessage, ServerResponse } from "http";

// Use TELEGRAM_LOCAL_API_URL if set (local Bot API server removes 20MB limit)
// To run locally: https://github.com/tdlib/telegram-bot-api
// Default: official cloud API (20MB file limit)
function getTelegramApiBase(): string {
  return (process.env.TELEGRAM_LOCAL_API_URL ?? "https://api.telegram.org").replace(/\/$/, "");
}

export async function getTelegramFileUrl(fileId: string): Promise<{ url: string | null; error?: string }> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.error("TELEGRAM_BOT_TOKEN not set");
    return { url: null, error: "Bot token not configured" };
  }

  const apiBase = getTelegramApiBase();

  try {
    const res = await fetch(`${apiBase}/bot${token}/getFile?file_id=${encodeURIComponent(fileId)}`);
    const data = (await res.json()) as {
      ok: boolean;
      result?: { file_path: string };
      description?: string;
    };

    if (!data.ok) {
      const desc = data.description ?? "Unknown error";
      logger.error({ fileId, desc }, "Telegram getFile failed");

      if (desc.includes("file is too big")) {
        return {
          url: null,
          error: "FILE_TOO_BIG",
        };
      }
      return { url: null, error: desc };
    }

    if (!data.result?.file_path) {
      return { url: null, error: "No file path returned" };
    }

    // For local API server: file path is an absolute local path
    // For cloud API: file path is relative, prefix with /file/bot<token>/
    const filePath = data.result.file_path;
    const isLocalServer = !apiBase.includes("api.telegram.org");

    let fileUrl: string;
    if (isLocalServer) {
      fileUrl = `${apiBase}/bot${token}/${filePath}`;
    } else {
      fileUrl = `${apiBase}/file/bot${token}/${filePath}`;
    }

    return { url: fileUrl };
  } catch (err) {
    logger.error({ err }, "getTelegramFileUrl error");
    return { url: null, error: "Network error reaching Telegram" };
  }
}

export async function proxyTelegramStream(
  fileId: string,
  req: IncomingMessage,
  res: ServerResponse
): Promise<void> {
  const { url: fileUrl, error } = await getTelegramFileUrl(fileId);

  if (!fileUrl) {
    if (error === "FILE_TOO_BIG") {
      res.writeHead(413, { "Content-Type": "application/json" });
      res.end(
        JSON.stringify({
          error: "FILE_TOO_BIG",
          message:
            "This file exceeds Telegram's 20MB Bot API limit. To stream large movies, deploy a Telegram Bot API Local Server and set TELEGRAM_LOCAL_API_URL. See README for setup.",
        })
      );
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: error ?? "File not found" }));
    }
    return;
  }

  const rangeHeader = (req as any).headers?.range as string | undefined;
  const headers: Record<string, string> = {};
  if (rangeHeader) {
    headers["Range"] = rangeHeader;
  }

  try {
    const upstream = await fetch(fileUrl, { headers });
    const statusCode = upstream.status;

    const contentType = upstream.headers.get("content-type") ?? "video/mp4";
    const contentLength = upstream.headers.get("content-length");
    const contentRange = upstream.headers.get("content-range");
    const acceptRanges = upstream.headers.get("accept-ranges") ?? "bytes";

    const responseHeaders: Record<string, string> = {
      "Content-Type": contentType,
      "Accept-Ranges": acceptRanges,
      "Cache-Control": "no-cache",
      "Access-Control-Allow-Origin": "*",
    };
    if (contentLength) responseHeaders["Content-Length"] = contentLength;
    if (contentRange) responseHeaders["Content-Range"] = contentRange;

    res.writeHead(statusCode, responseHeaders);

    if (!upstream.body) {
      res.end();
      return;
    }

    const reader = upstream.body.getReader();
    const pump = async () => {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const canContinue = res.write(value);
        if (!canContinue) {
          await new Promise<void>((resolve) => (res as any).once("drain", resolve));
        }
      }
      res.end();
    };
    await pump();
  } catch (err) {
    logger.error({ err }, "proxyTelegramStream error");
    if (!res.headersSent) {
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Streaming error" }));
    }
  }
}
