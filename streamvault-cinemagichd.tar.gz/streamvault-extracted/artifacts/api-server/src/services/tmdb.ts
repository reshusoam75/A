import { logger } from "../lib/logger.js";

const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

export interface TMDBMovie {
  title: string;
  poster: string;
  description: string;
  rating: number;
  year: number;
  genre: string[];
}

export async function fetchMovieMetadata(title: string): Promise<TMDBMovie | null> {
  const apiKey = process.env.TMDB_API_KEY;
  if (!apiKey) {
    logger.error("TMDB_API_KEY not set");
    return null;
  }

  try {
    const searchUrl = `${TMDB_BASE}/search/movie?api_key=${apiKey}&query=${encodeURIComponent(title)}&language=en-US&page=1`;
    const searchRes = await fetch(searchUrl);
    if (!searchRes.ok) {
      logger.error({ status: searchRes.status }, "TMDB search failed");
      return null;
    }
    const searchData = (await searchRes.json()) as { results: any[] };
    if (!searchData.results || searchData.results.length === 0) {
      logger.warn({ title }, "No TMDB results found");
      return null;
    }

    const movie = searchData.results[0];

    // Fetch genre info
    const genreRes = await fetch(`${TMDB_BASE}/genre/movie/list?api_key=${apiKey}&language=en-US`);
    const genreData = (await genreRes.json()) as { genres: { id: number; name: string }[] };
    const genreMap: Record<number, string> = {};
    for (const g of genreData.genres ?? []) {
      genreMap[g.id] = g.name;
    }

    const genres = (movie.genre_ids ?? []).map((id: number) => genreMap[id] ?? "").filter(Boolean);

    return {
      title: movie.title ?? title,
      poster: movie.poster_path ? `${TMDB_IMAGE_BASE}${movie.poster_path}` : "",
      description: movie.overview ?? "",
      rating: parseFloat((movie.vote_average ?? 0).toFixed(1)),
      year: movie.release_date ? parseInt(movie.release_date.split("-")[0]) : 0,
      genre: genres,
    };
  } catch (err) {
    logger.error({ err }, "TMDB fetch error");
    return null;
  }
}
