# StreamVault — Movie Streaming Platform

## Overview

A complete movie streaming platform using Telegram as file storage, TMDB for metadata, MongoDB for the database, and a Netflix-style frontend.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: MongoDB + Mongoose
- **Bot**: Telegraf (Telegram bot)
- **Build**: esbuild (CJS bundle)

## Architecture

```
artifacts/api-server/
├── src/
│   ├── app.ts              # Express app setup, static file serving
│   ├── index.ts            # Server entrypoint, MongoDB connect, bot start
│   ├── models/
│   │   └── Movie.ts        # Mongoose Movie model (title, file_id, poster, etc.)
│   ├── services/
│   │   ├── db.ts           # MongoDB connection
│   │   ├── tmdb.ts         # TMDB API metadata fetching
│   │   └── telegram.ts     # Telegram file URL + streaming proxy
│   ├── controllers/
│   │   └── movieController.ts  # getMovies, getMovieById, searchMovies, streamMovie
│   ├── routes/
│   │   ├── index.ts        # Router aggregator
│   │   ├── health.ts       # GET /api/healthz
│   │   └── movies.ts       # GET /api/movies, /api/movie/:id, /api/search, /api/stream/:file_id
│   └── bot/
│       └── index.ts        # Telegraf bot — listens for channel uploads
└── public/
    ├── index.html          # StreamVault default frontend (Telegram-connected)
    ├── style.css           # Dark UI styles
    ├── app.js              # Frontend JavaScript
    ├── user.html           # CinemagicHD User Panel (Firebase-powered, no login required)
    └── admin.html          # CinemagicHD Admin Panel (Firebase-powered, requires login)
```

## REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/healthz | Health check |
| GET | /api/movies | List all movies |
| GET | /api/movie/:id | Get movie by ID |
| GET | /api/search?q= | Search movies by title |
| GET | /api/stream/:file_id | Proxy stream video from Telegram |

## Frontend

- Served at `/api/static/` from the Express server
- Homepage: movie grid with posters, hero section with featured movie
- Click any card to open a video player modal
- Search bar filters movies via the API

## Telegram Bot

- Listens for `channel_post` events in the configured channel
- Detects video/document uploads with a caption
- Caption is used as the movie title to query TMDB
- Movie metadata (poster, description, rating, year, genre) saved to MongoDB

## Environment Variables Required

| Key | Description |
|-----|-------------|
| TELEGRAM_BOT_TOKEN | Bot token from @BotFather |
| TELEGRAM_CHANNEL_ID | Channel ID (e.g. -100123456789) |
| TMDB_API_KEY | TMDB v3 API key |
| MONGODB_URI | MongoDB Atlas connection string |

## Key Commands

- `pnpm --filter @workspace/api-server run dev` — run server + bot locally
- `pnpm --filter @workspace/api-server run build` — build for production

## IMPORTANT: MongoDB Atlas Setup

The MongoDB Atlas cluster must allow inbound connections from all IPs:
1. Go to Atlas → Network Access
2. Add IP Address → Allow Access from Anywhere (0.0.0.0/0)
3. Save and wait ~30 seconds for it to apply

## Deployment

### Railway / Render (Backend)
1. Connect your GitHub repo
2. Set environment variables: TELEGRAM_BOT_TOKEN, TELEGRAM_CHANNEL_ID, TMDB_API_KEY, MONGODB_URI
3. Build command: `pnpm --filter @workspace/api-server run build`
4. Start command: `node artifacts/api-server/dist/index.mjs`

### MongoDB Atlas
1. Create free M0 cluster at https://cloud.mongodb.com
2. Create database user with read/write access
3. Set Network Access to allow 0.0.0.0/0
4. Get connection string (SRV format)

## CinemagicHD Panels (Firebase)

The `user.html` and `admin.html` panels run independently using Firebase Realtime Database.

### Setup
1. Go to https://console.firebase.google.com and create a project
2. Enable **Realtime Database** and **Authentication → Email/Password**
3. Open `user.html` and `admin.html` and replace the `firebaseConfig` block at the top
4. In Firebase Console → Authentication → Users, add an admin email/password

### Panel URLs (when served via Express)
- User Panel: `/api/static/user.html`
- Admin Panel: `/api/static/admin.html`

### Firebase Database Rules (paste in Firebase Console)
```json
{
  "rules": {
    "movies": { ".read": true, ".write": "auth != null" },
    "reports": { ".read": "auth != null", ".write": true }
  }
}
```

## Troubleshooting

| Error | Fix |
|-------|-----|
| `querySrv ENOTFOUND` | Atlas Network Access must allow 0.0.0.0/0 |
| Bot not detecting uploads | Make bot an admin in the channel |
| No movies in grid | Upload a video to Telegram channel with a caption |
| Stream fails | Ensure TELEGRAM_BOT_TOKEN is correct and bot can access files |
| TMDB returns null | Check TMDB_API_KEY and movie caption spelling |
